rps player_rock(int round,rps *myhist,rps *opphist) {
	return Rock;
}

register_player(player_rock,"rock");
