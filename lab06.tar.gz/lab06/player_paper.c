rps player_paper(int round,rps *myhist,rps *opphist) {
	return Paper;
}

register_player(player_paper,"paper");
