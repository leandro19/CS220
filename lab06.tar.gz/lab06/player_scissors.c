rps player_scissors(int round,rps *myhist,rps *opphist) {
	return Scissors;
}

register_player(player_scissors,"scissors");
